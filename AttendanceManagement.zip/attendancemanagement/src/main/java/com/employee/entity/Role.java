package com.employee.entity;


public enum Role {
	MANAGER,
	EMPLOYEE
}
