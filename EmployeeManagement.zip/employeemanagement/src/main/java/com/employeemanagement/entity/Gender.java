package com.employeemanagement.entity;

public enum Gender {
	
	M,
	F

}
