package com.employeemanagement.entity;

public enum Role {
	
	EMPLOYEE,
	MANAGER

}
