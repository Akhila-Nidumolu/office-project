package com.example.shiftmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiftmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
