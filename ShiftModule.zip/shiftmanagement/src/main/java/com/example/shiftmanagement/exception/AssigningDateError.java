package com.example.shiftmanagement.exception;

public class AssigningDateError extends Exception {
	public AssigningDateError(String msg) {
		super(msg);
	}
}
