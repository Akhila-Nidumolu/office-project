package com.example.shiftmanagement.exception;

public class CannotUpdateStatusException extends Exception {
	public CannotUpdateStatusException(String msg) {
		super(msg);
	}
}
