package com.example.shiftmanagement.exception;

public class SameNameException extends Exception {
	public SameNameException(String msg) {
		super(msg);
	}
}
