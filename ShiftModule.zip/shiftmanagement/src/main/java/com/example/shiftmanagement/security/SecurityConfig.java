package com.example.shiftmanagement.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.context.request.RequestAttributes;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import feign.RequestInterceptor;
//import jakarta.servlet.http.HttpServletRequest;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	private JwtFilter jwtFilter;

	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, CorsConfigurationSource corsConfigurationSource) throws Exception {
        return http
            .cors(cors -> cors.configurationSource(corsConfigurationSource)) // Apply CORS settings correctly
            .csrf(csrf -> csrf.disable())
				.authorizeHttpRequests(request -> request
                        .requestMatchers("/shiftassignments/**","/shift-requests/**","/updatedrequests/**").authenticated()
                        .anyRequest().authenticated())
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class).build();

	}

//    @Bean
//	RequestInterceptor requestInterceptor() {
//		return requestTemplate -> {
//			RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
//			if(requestAttributes instanceof ServletRequestAttributes servletRequestAttributes) {
//				HttpServletRequest request = servletRequestAttributes.getRequest();
//				String authHeader = request.getHeader("AUTHORIZATION");
//				System.out.print(">>>>>>>>>>>>" + authHeader);
//				if(authHeader != null && !authHeader.isEmpty()) {
//					requestTemplate.header("AUTHORIZATION", authHeader);
//				}
//			}
//		};
//	}
//
//    @Bean
//    public AuthenticationProvider authenticationProvider() {
//        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
//        provider.setPasswordEncoder(new BCryptPasswordEncoder(12));
//        provider.setUserDetailsService(userDetailsService);
//
//
//        return provider;
//    }

//    @Bean
//    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
//        return config.getAuthenticationManager();
//
//    }
}
