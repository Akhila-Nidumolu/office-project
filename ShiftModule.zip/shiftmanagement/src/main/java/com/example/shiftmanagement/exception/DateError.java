package com.example.shiftmanagement.exception;

public class DateError extends Exception {
	public DateError(String msg) {
		super(msg);
	}
}
