package com.leavemanagement.entity;

public enum Role {
	
	EMPLOYEE,
	MANAGER

}
