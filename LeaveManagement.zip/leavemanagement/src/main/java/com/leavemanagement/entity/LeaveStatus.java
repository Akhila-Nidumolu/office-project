package com.leavemanagement.entity;

public enum LeaveStatus {
	
	PENDING,
	APPROVED,
	REJECTED, 
	CANCELLED

}
