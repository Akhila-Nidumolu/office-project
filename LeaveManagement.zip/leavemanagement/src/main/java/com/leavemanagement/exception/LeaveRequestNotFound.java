package com.leavemanagement.exception;

public class LeaveRequestNotFound extends RuntimeException{
	
	public LeaveRequestNotFound(String msg) {
		super(msg);
	}

}
